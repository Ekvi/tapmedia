@extends('layouts.app')

@section('content')

    <div class="alert alert-danger">
        {{$message}}
    </div>

@endsection