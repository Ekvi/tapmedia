<?php $__env->startSection('content'); ?>

    <a href="<?php echo e(route('domains.create')); ?>" class="btn btn-primary">Add Domain</a>

    <br><br>

    <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($domain->id); ?></td>
                    <td><?php echo e($domain->name); ?></td>
                    <td class="table-centred">
                        <a href="domains/<?php echo e($domain->id); ?>/edit" role="button"><i class="fa fa-wrench fa-2x"></i></a>
                    </td>
                    <td class="table-centred">
                        <form action="domains/<?php echo e($domain->id); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="_method" value="DELETE" />
                            <button type="submit" class="btn-delete"><i class="fa fa-close fa-2x"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>